package com.example.currencyapi.model;

public class Currency {
}
