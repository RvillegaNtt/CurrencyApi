package com.example.currencyapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurrencyapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurrencyapiApplication.class, args);
	}


}
