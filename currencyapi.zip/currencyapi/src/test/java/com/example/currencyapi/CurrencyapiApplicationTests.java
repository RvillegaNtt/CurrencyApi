package com.example.currencyapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
